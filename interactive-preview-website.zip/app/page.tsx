import { AnimatedBackground } from "@/components/animated-background"
import { Hero } from "@/components/hero"
import { Flipbook, type BookPage } from "@/components/flipbook"
import { HowToUse } from "@/components/how-to-use"

const pages: BookPage[] = [
  { src: "/portada.jpg", title: "Portada" },
  { src: "/terminos.jpg", title: "Términos" },
  { src: "/descarga.jpg", title: "Descarga" },
]

export default function Page() {
  return (
    <main className="relative min-h-screen overflow-hidden">
      <AnimatedBackground />
      <Hero />
      <section className="px-6 py-14 md:py-20">
        <Flipbook pages={pages} />
      </section>
      <HowToUse />
      <footer className="border-t border-border px-6 py-8 text-center text-xs text-muted-foreground">
        Vista Previa Interactiva — pasa las páginas para vivir la experiencia
      </footer>
    </main>
  )
}
