export function Hero() {
  return (
    <section className="flex flex-col items-center px-6 pt-16 text-center md:pt-24">
      <span className="mb-5 inline-flex items-center gap-2 rounded-full border border-border bg-card/60 px-4 py-1.5 text-xs font-medium uppercase tracking-widest text-muted-foreground backdrop-blur-sm">
        <span className="size-1.5 rounded-full bg-primary" aria-hidden="true" />
        Edición digital
      </span>
      <h1 className="font-heading text-balance text-4xl font-bold leading-tight tracking-tight sm:text-5xl md:text-6xl lg:text-7xl">
        VISTA PREVIA{" "}
        <span className="bg-gradient-to-r from-primary to-[oklch(0.72_0.13_55)] bg-clip-text text-transparent">
          INTERACTIVA
        </span>
      </h1>
      <p className="mt-5 max-w-md text-pretty text-base leading-relaxed text-muted-foreground sm:text-lg">
        Pasa las páginas del libro para vivir la experiencia
      </p>
    </section>
  )
}
