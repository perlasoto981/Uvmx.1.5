"use client"

import Image from "next/image"
import { useRef, useState } from "react"
import { Check, Download, FileArchive, Lock } from "lucide-react"
import { Flipbook, type BookPage, type FlipbookHandle } from "@/components/flipbook"

export function BookExperience() {
  const bookRef = useRef<FlipbookHandle>(null)
  const [accepted, setAccepted] = useState(false)
  const [checkboxOn, setCheckboxOn] = useState(false)

  const stop = (e: React.PointerEvent) => e.stopPropagation()

  const pages: BookPage[] = [
    {
      id: "portada",
      title: "Portada",
      content: (
        <div className="flex h-full flex-col items-center justify-center gap-6 bg-gradient-to-b from-card to-background p-8 text-center">
          <Image
            src="/uvmx-logo.png"
            alt="Logo de UniqueVibesMX"
            width={220}
            height={220}
            className="size-40 rounded-full object-cover ring-1 ring-primary/40 sm:size-48"
            priority
          />
          <div className="space-y-2">
            <p className="font-heading text-2xl font-bold uppercase tracking-[0.25em] text-foreground">
              UniqueVibes
              <span className="text-primary">MX</span>
            </p>
            <p className="text-xs uppercase tracking-[0.3em] text-muted-foreground">
              Crea. Diseña. Personaliza. <span className="text-primary">Inspira.</span>
            </p>
          </div>
          <p className="mt-4 text-xs text-muted-foreground">
            Arrastra el borde derecho para comenzar
          </p>
        </div>
      ),
    },
    {
      id: "terminos",
      title: "Términos y Condiciones",
      content: (
        <div className="flex h-full flex-col gap-4 p-6 sm:p-7">
          <header>
            <h2 className="font-heading text-xl font-bold uppercase leading-tight text-foreground">
              Términos y<br />
              <span className="text-primary">Condiciones</span>
            </h2>
            <p className="mt-1 text-[11px] font-semibold uppercase tracking-widest text-muted-foreground">
              Política de reembolso y reclamo
            </p>
          </header>

          <ul className="space-y-2.5 text-[13px] leading-relaxed text-muted-foreground">
            <li className="flex gap-2">
              <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" />
              Al adquirir este producto digital, aceptas los siguientes términos y condiciones.
            </li>
            <li className="flex gap-2">
              <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" />
              Este producto es 100% digital. No se realizan reembolsos una vez completada la compra.
            </li>
            <li className="flex gap-2">
              <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" />
              No está permitido compartir, revender o distribuir este producto.
            </li>
            <li className="flex gap-2">
              <span className="mt-1.5 size-1.5 shrink-0 rounded-full bg-primary" />
              En caso de error en el acceso a los archivos, puedes contactarnos dentro de los 7 días
              posteriores a tu compra para revisión.
            </li>
          </ul>

          <label
            onPointerDown={stop}
            className="mt-auto flex cursor-pointer items-start gap-3 rounded-lg border border-border bg-secondary/50 p-3 text-[13px] text-foreground"
          >
            <button
              type="button"
              role="checkbox"
              aria-checked={checkboxOn}
              onPointerDown={stop}
              onClick={() => setCheckboxOn((v) => !v)}
              className={`mt-0.5 inline-flex size-5 shrink-0 items-center justify-center rounded border transition ${
                checkboxOn ? "border-primary bg-primary text-primary-foreground" : "border-border bg-background"
              }`}
            >
              {checkboxOn && <Check className="size-3.5" />}
            </button>
            <span>
              He leído y acepto todos los términos y condiciones, incluyendo la política de reembolsos y
              reclamo.
            </span>
          </label>

          <button
            type="button"
            onPointerDown={stop}
            disabled={!checkboxOn}
            onClick={() => {
              setAccepted(true)
              bookRef.current?.next()
            }}
            className="inline-flex h-11 w-full items-center justify-center rounded-lg bg-primary font-heading text-sm font-semibold uppercase tracking-wider text-primary-foreground transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
          >
            Aceptar y continuar
          </button>
        </div>
      ),
    },
    {
      id: "descarga",
      title: "Instrucciones y Descarga",
      content: (
        <div className="flex h-full flex-col gap-4 p-6 sm:p-7">
          <header>
            <h2 className="font-heading text-xl font-bold uppercase leading-tight text-foreground">
              Instrucciones<br />y <span className="text-primary">Descarga</span>
            </h2>
          </header>

          <ol className="space-y-2.5 text-[13px] leading-relaxed text-muted-foreground">
            <li className="flex gap-3">
              <span className="font-heading font-bold text-primary">1.</span>
              Haz clic en el botón de descarga para obtener tus archivos.
            </li>
            <li className="flex gap-3">
              <span className="font-heading font-bold text-primary">2.</span>
              Descomprime el archivo .zip en una carpeta de tu preferencia.
            </li>
            <li className="flex gap-3">
              <span className="font-heading font-bold text-primary">3.</span>
              Abre los archivos y disfruta de tu producto.
            </li>
          </ol>

          <div className="mt-auto rounded-xl border border-border bg-secondary/50 p-4">
            <div className="flex items-center gap-3">
              <div className="flex size-12 shrink-0 items-center justify-center rounded-lg bg-primary/15 text-primary">
                <FileArchive className="size-6" />
              </div>
              <div className="min-w-0">
                <p className="truncate font-heading text-sm font-semibold text-foreground">
                  UVMX_PACK.zip
                </p>
                <p className="text-xs text-muted-foreground">Tamaño: 1.2 GB</p>
              </div>
            </div>

            <button
              type="button"
              onPointerDown={stop}
              disabled={!accepted}
              onClick={() => {
                if (accepted) window.open("https://uniquevibesmx.com", "_blank", "noopener")
              }}
              className="mt-4 inline-flex h-11 w-full items-center justify-center gap-2 rounded-lg bg-primary font-heading text-sm font-semibold uppercase tracking-wider text-primary-foreground transition hover:opacity-90 disabled:cursor-not-allowed disabled:opacity-40"
            >
              {accepted ? <Download className="size-4" /> : <Lock className="size-4" />}
              {accepted ? "Descargar archivo" : "Acepta los términos"}
            </button>

            {!accepted && (
              <p className="mt-2 text-center text-[11px] text-muted-foreground">
                Debes aceptar los términos en la página anterior para desbloquear la descarga.
              </p>
            )}
          </div>
        </div>
      ),
    },
  ]

  return <Flipbook ref={bookRef} pages={pages} />
}
