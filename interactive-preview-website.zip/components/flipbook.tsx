"use client"

import type React from "react"
import {
  forwardRef,
  useCallback,
  useEffect,
  useImperativeHandle,
  useRef,
  useState,
} from "react"
import { ChevronLeft, ChevronRight, Volume2, VolumeX } from "lucide-react"

export type BookPage = {
  id: string
  title: string
  content: React.ReactNode
}

export type FlipbookHandle = {
  next: () => void
  prev: () => void
  goTo: (i: number) => void
}

type DragState = {
  active: boolean
  pointerId: number
  startX: number
  index: number
  dir: "forward" | "backward"
  rotation: number
}

const IDLE: DragState = {
  active: false,
  pointerId: -1,
  startX: 0,
  index: -1,
  dir: "forward",
  rotation: 0,
}

const EDGE = 0.2 // fraction of width that acts as a drag handle

export const Flipbook = forwardRef<FlipbookHandle, { pages: BookPage[] }>(
  function Flipbook({ pages }, ref) {
    const total = pages.length
    const [current, setCurrent] = useState(0)
    const currentRef = useRef(0)
    const [drag, setDrag] = useState<DragState>(IDLE)
    const [soundOn, setSoundOn] = useState(false)
    const soundRef = useRef(false)
    const containerRef = useRef<HTMLDivElement>(null)
    const audioCtxRef = useRef<AudioContext | null>(null)

    useEffect(() => {
      currentRef.current = current
    }, [current])
    useEffect(() => {
      soundRef.current = soundOn
    }, [soundOn])

    // --- Synthesized page-turn sound (no asset needed) ---
    const playFlip = useCallback(() => {
      if (!soundRef.current) return
      try {
        if (!audioCtxRef.current) {
          const Ctx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext
          audioCtxRef.current = new Ctx()
        }
        const ctx = audioCtxRef.current
        if (!ctx) return
        if (ctx.state === "suspended") void ctx.resume()

        const duration = 0.32
        const buffer = ctx.createBuffer(1, ctx.sampleRate * duration, ctx.sampleRate)
        const data = buffer.getChannelData(0)
        for (let i = 0; i < data.length; i++) {
          const t = i / data.length
          const envelope = Math.sin(Math.PI * t) ** 2
          data[i] = (Math.random() * 2 - 1) * envelope
        }
        const source = ctx.createBufferSource()
        source.buffer = buffer
        const filter = ctx.createBiquadFilter()
        filter.type = "bandpass"
        filter.frequency.setValueAtTime(1200, ctx.currentTime)
        filter.frequency.exponentialRampToValueAtTime(4500, ctx.currentTime + duration)
        filter.Q.value = 0.7
        const gain = ctx.createGain()
        gain.gain.setValueAtTime(0.0001, ctx.currentTime)
        gain.gain.exponentialRampToValueAtTime(0.45, ctx.currentTime + 0.04)
        gain.gain.exponentialRampToValueAtTime(0.0001, ctx.currentTime + duration)
        source.connect(filter)
        filter.connect(gain)
        gain.connect(ctx.destination)
        source.start()
        source.stop(ctx.currentTime + duration)
      } catch {
        // audio unavailable, ignore
      }
    }, [])

    const goTo = useCallback(
      (next: number) => {
        const clamped = Math.max(0, Math.min(total, next))
        setCurrent((prev) => {
          if (clamped !== prev) playFlip()
          return clamped
        })
      },
      [total, playFlip],
    )

    useImperativeHandle(
      ref,
      () => ({
        next: () => goTo(currentRef.current + 1),
        prev: () => goTo(currentRef.current - 1),
        goTo,
      }),
      [goTo],
    )

    // --- Drag handling (only from page edges) ---
    const onPointerDown = (e: React.PointerEvent) => {
      if (drag.active) return
      const rect = containerRef.current?.getBoundingClientRect()
      if (!rect) return
      const x = e.clientX - rect.left
      const startX = e.clientX

      const nearRight = x > rect.width * (1 - EDGE)
      const nearLeft = x < rect.width * EDGE

      let dir: "forward" | "backward"
      let index: number
      if (nearRight && current < total) {
        dir = "forward"
        index = current
      } else if (nearLeft && current > 0) {
        dir = "backward"
        index = current - 1
      } else {
        return // let inner content handle the interaction
      }

      ;(e.target as Element).setPointerCapture?.(e.pointerId)
      setDrag({
        active: true,
        pointerId: e.pointerId,
        startX,
        index,
        dir,
        rotation: dir === "forward" ? 0 : -180,
      })
    }

    const onPointerMove = (e: React.PointerEvent) => {
      if (!drag.active || e.pointerId !== drag.pointerId) return
      const rect = containerRef.current?.getBoundingClientRect()
      if (!rect) return
      const delta = e.clientX - drag.startX
      const ratio = delta / rect.width
      let rotation: number
      if (drag.dir === "forward") {
        rotation = Math.max(-180, Math.min(0, ratio * 180))
      } else {
        rotation = Math.max(-180, Math.min(0, -180 + ratio * 180))
      }
      setDrag((d) => ({ ...d, rotation }))
    }

    const endDrag = (e: React.PointerEvent) => {
      if (!drag.active || e.pointerId !== drag.pointerId) return
      const passedHalf = drag.rotation <= -90
      if (drag.dir === "forward") {
        if (passedHalf) goTo(current + 1)
      } else {
        if (!passedHalf) goTo(current - 1)
      }
      setDrag(IDLE)
    }

    useEffect(() => {
      const onKey = (e: KeyboardEvent) => {
        if (e.key === "ArrowRight") goTo(currentRef.current + 1)
        if (e.key === "ArrowLeft") goTo(currentRef.current - 1)
      }
      window.addEventListener("keydown", onKey)
      return () => window.removeEventListener("keydown", onKey)
    }, [goTo])

    const getRotation = (i: number) => {
      if (drag.active && i === drag.index) return drag.rotation
      return i < current ? -180 : 0
    }
    const getZIndex = (i: number) => {
      if (drag.active && i === drag.index) return total + 5
      if (i < current) return i + 1
      return total - i
    }

    return (
      <div className="flex w-full flex-col items-center">
        <div
          ref={containerRef}
          onPointerDown={onPointerDown}
          onPointerMove={onPointerMove}
          onPointerUp={endDrag}
          onPointerCancel={endDrag}
          className="relative aspect-[3/4] w-full max-w-md touch-none select-none [perspective:2400px]"
          role="group"
          aria-label="Vista previa del libro. Arrastra los bordes para pasar las páginas."
        >
          {/* Binding / spine on the left */}
          <div
            aria-hidden="true"
            className="absolute -left-3 top-2 bottom-2 z-0 w-3 rounded-l-md bg-gradient-to-r from-black/60 to-primary/30"
          />
          {/* Base page (revealed when book is finished) */}
          <div className="absolute inset-0 overflow-hidden rounded-xl border border-border bg-card">
            <div className="flex h-full w-full flex-col items-center justify-center gap-3 text-muted-foreground">
              <span className="font-heading text-sm uppercase tracking-[0.3em]">
                Fin de la vista previa
              </span>
            </div>
          </div>

          {pages.map((page, i) => {
            const rotation = getRotation(i)
            const isActive = drag.active && i === drag.index
            const isTopFront = i === current
            return (
              <div
                key={page.id}
                className="absolute inset-0 origin-left [transform-style:preserve-3d]"
                style={{
                  transform: `rotateY(${rotation}deg)`,
                  zIndex: getZIndex(i),
                  transition: isActive
                    ? "none"
                    : "transform 0.7s cubic-bezier(0.4, 0.0, 0.2, 1)",
                }}
              >
                {/* Front face */}
                <div className="absolute inset-0 overflow-hidden rounded-xl border border-border bg-card [backface-visibility:hidden]">
                  <div className="h-full w-full overflow-y-auto">{page.content}</div>
                  {/* spine shadow */}
                  <div className="pointer-events-none absolute inset-y-0 left-0 w-8 bg-gradient-to-r from-black/40 to-transparent" />
                  {/* right-edge grab hint on the active top page */}
                  {isTopFront && i < total && (
                    <div className="pointer-events-none absolute inset-y-0 right-0 w-10 bg-gradient-to-l from-primary/20 to-transparent" />
                  )}
                </div>
                {/* Back face */}
                <div
                  className="absolute inset-0 overflow-hidden rounded-xl border border-border bg-card [backface-visibility:hidden]"
                  style={{ transform: "rotateY(180deg)" }}
                >
                  <div className="flex h-full w-full items-center justify-center">
                    <div className="pointer-events-none absolute inset-y-0 right-0 w-8 bg-gradient-to-l from-black/40 to-transparent" />
                    <span className="font-heading text-xs uppercase tracking-[0.35em] text-primary/40">
                      UVMX
                    </span>
                  </div>
                </div>
              </div>
            )
          })}
        </div>

        {/* Controls */}
        <div className="mt-7 flex items-center gap-3">
          <button
            type="button"
            onClick={() => goTo(current - 1)}
            disabled={current === 0}
            aria-label="Página anterior"
            className="inline-flex size-11 items-center justify-center rounded-full border border-border bg-card text-foreground transition hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-40"
          >
            <ChevronLeft className="size-5" />
          </button>

          <div className="flex items-center gap-2">
            {pages.map((p, i) => (
              <span
                key={p.id}
                aria-hidden="true"
                className={`size-2.5 rounded-full transition ${
                  i === Math.min(current, total - 1) ? "bg-primary" : "bg-muted-foreground/40"
                }`}
              />
            ))}
          </div>

          <button
            type="button"
            onClick={() => goTo(current + 1)}
            disabled={current >= total}
            aria-label="Página siguiente"
            className="inline-flex size-11 items-center justify-center rounded-full border border-border bg-card text-foreground transition hover:bg-secondary disabled:cursor-not-allowed disabled:opacity-40"
          >
            <ChevronRight className="size-5" />
          </button>

          <button
            type="button"
            onClick={() => setSoundOn((s) => !s)}
            aria-pressed={soundOn}
            aria-label={soundOn ? "Desactivar sonido" : "Activar sonido"}
            className={`ml-1 inline-flex h-11 items-center gap-2 rounded-full border px-4 transition ${
              soundOn
                ? "border-primary bg-primary text-primary-foreground"
                : "border-border bg-card text-foreground hover:bg-secondary"
            }`}
          >
            {soundOn ? <Volume2 className="size-5" /> : <VolumeX className="size-5" />}
            <span className="text-xs font-semibold uppercase tracking-widest">Sonido</span>
          </button>
        </div>

        <p className="mt-4 text-xs text-muted-foreground">
          Arrastra los bordes o usa las flechas del teclado
        </p>
      </div>
    )
  },
)
