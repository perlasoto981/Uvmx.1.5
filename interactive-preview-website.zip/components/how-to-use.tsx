import { Hand, Volume2, Lock, ShieldCheck } from "lucide-react"

const items = [
  {
    icon: Hand,
    title: "Arrastra para pasar páginas",
    desc: "Desliza con el dedo o el ratón sobre el libro.",
  },
  {
    icon: Volume2,
    title: "Activa el sonido",
    desc: "Escucha el efecto de pasar cada hoja.",
  },
  {
    icon: Lock,
    title: "Debes aceptar términos",
    desc: "Revisa la página de términos antes de continuar.",
  },
  {
    icon: ShieldCheck,
    title: "Compra segura",
    desc: "Tu descarga está protegida de principio a fin.",
  },
]

export function HowToUse() {
  return (
    <section className="mx-auto w-full max-w-5xl px-6 py-16 md:py-24">
      <h2 className="mb-10 text-center font-heading text-2xl font-bold tracking-tight sm:text-3xl">
        Cómo usar
      </h2>
      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {items.map(({ icon: Icon, title, desc }) => (
          <div
            key={title}
            className="flex flex-col gap-3 rounded-2xl border border-border bg-card/60 p-6 backdrop-blur-sm transition hover:border-primary/40"
          >
            <span className="inline-flex size-11 items-center justify-center rounded-xl bg-primary/15 text-primary">
              <Icon className="size-5" />
            </span>
            <h3 className="font-heading text-base font-semibold leading-snug text-balance">
              {title}
            </h3>
            <p className="text-sm leading-relaxed text-muted-foreground text-pretty">{desc}</p>
          </div>
        ))}
      </div>
    </section>
  )
}
